from django.shortcuts import render, redirect
from .models import Team, Game
from .forms import TeamForm, GameForm

def home(request):
    return render(request, 'home.html')

def add_team(request):
    if request.method == 'POST':
        form = TeamForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('team_list')
    else:
        form = TeamForm()
    return render(request, 'add_team.html', {'form': form})

def add_game(request):
    if request.method == 'POST':
        form = GameForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('game_list')
    else:
        form = GameForm()
    return render(request, 'add_game.html', {'form': form})

def team_list(request):
    teams = Team.objects.all()
    return render(request, 'team_list.html', {'teams': teams})

def game_list(request):
    games = Game.objects.all()
    return render(request, 'game_list.html', {'games': games})
