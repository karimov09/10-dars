from django.urls import path
from . import views

urlpatterns = [
    path('add_team/', views.add_team, name='add_team'),
    path('', views.home, name='home'),
    path('add_game/', views.add_game, name='add_game'),
    path('teams/', views.team_list, name='team_list'),
    path('games/', views.game_list, name='game_list'),
]
