from django.contrib import admin
from .models import Team, Game

@admin.register(Team)
class TeamAdmin(admin.ModelAdmin):
    list_display = ['name', 'city']

@admin.register(Game)
class GameAdmin(admin.ModelAdmin):
    list_display = ['home_team', 'away_team', 'score', 'date']
