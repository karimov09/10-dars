from django import forms
from .models import Team, Game

class TeamForm(forms.ModelForm):
    class Meta:
        model = Team
        fields = ['name', 'city']

class GameForm(forms.ModelForm):
    class Meta:
        model = Game
        fields = ['home_team', 'away_team', 'score', 'date']
